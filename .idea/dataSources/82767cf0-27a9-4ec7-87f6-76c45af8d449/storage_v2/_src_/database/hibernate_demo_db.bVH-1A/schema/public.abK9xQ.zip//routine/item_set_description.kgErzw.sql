create function item_set_description() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.description IS NULL THEN
        NEW.description := 'text from trigger';
    END IF;

    RETURN NEW;
END;
$$;

alter function item_set_description() owner to postgres;

